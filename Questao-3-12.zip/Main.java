package meuPacote;
import java.util.InputMismatchException;
import javax.swing.JOptionPane;

public class TestaCPF {

public static void main(String[] args){

  String CPF;
  String nome;

  nome = JOptionPane.showInputDialog("Digite seu nome:");
  CPF = JOptionPane.showInputDialog("Digite seu CPF:");


  if(validaCPF.isCPF(CPF) == true)
    JOptionPane.showMessageDialog(null, "CPF Válido" + validaCPF , imprimeCPF(CPF));
  else
    JOptionPane.showMessageDialog(null, "CPF Inválido");

    }
}


